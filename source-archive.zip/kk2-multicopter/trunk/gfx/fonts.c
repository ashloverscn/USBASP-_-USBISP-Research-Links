/*
 * fonts.c
 *
 * Created: 14.08.2012 17:41:29
 *  Author: OliverS
 *
 * $Id: fonts.c 32 2012-08-24 12:03:25Z olischulz24@googlemail.com $
 */ 

#include "fonts.h"
#include <avr/pgmspace.h>

/*
const fontdescriptor_t *fonts[] PROGMEM = {
	&font4x6,
	&font6x8,
	&font12x16,
};
*/
