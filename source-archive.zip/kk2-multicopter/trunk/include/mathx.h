/*
 * mathx.h
 *
 * Created: 23.02.2013 17:00:25
 *  Author: OliverS
 *
 * $Id: mathx.h 40 2013-02-24 17:05:25Z olischulz24@googlemail.com $
 */ 


#ifndef MATHX_H_
#define MATHX_H_

int16_t arctan2(int16_t y, int16_t x);


#endif /* MATHX_H_ */