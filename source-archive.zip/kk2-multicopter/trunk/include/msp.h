/*
 * msp.h
 *
 * Created: 26.02.2013 13:59:05
 *  Author: OliverS
 *
 * $Id: msp.h 46 2013-02-26 13:23:19Z olischulz24@googlemail.com $
 */ 


#ifndef MSP_H_
#define MSP_H_

void mspLoop();


#endif /* MSP_H_ */